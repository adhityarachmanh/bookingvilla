// https://vuex.vuejs.org/en/state.html

export default {
  admin: null,
  loading: false,
  error: {
    status: false,
    msg: null
  }
}
