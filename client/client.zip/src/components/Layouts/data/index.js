export const navItem = [
  { name: "About Us" },
  { name: "Galery" },
  { name: "Pavilion" },
];
